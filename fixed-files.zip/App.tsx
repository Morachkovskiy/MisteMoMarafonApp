import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { BottomNavigation } from "@/components/ui/navigation";
import { useAuth } from "@/hooks/useAuth";

// Импортируем все страницы, включая новые
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Welcome from "./pages/Welcome";
import Onboarding from "./pages/Onboarding";
import Pricing from "./pages/Pricing";
import Shop from "./pages/Shop";
import Scanner from "./pages/Scanner";
import Chat from "./pages/Chat";
import Profile from "./pages/Profile";
import Themes from "./pages/Themes";
import Schedule from "./pages/Schedule";
import Workout from "./pages/Workout";
import Breathing from "./pages/Breathing";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function AppContent() {
  const { user, loading } = useAuth();
  const onboardingDone = typeof window !== 'undefined' ? localStorage.getItem('onboarding_done') === 'true' : false;
  const subscriptionTier = typeof window !== 'undefined' ? localStorage.getItem('subscription_tier') : null;
  const isAuthenticated = !!user;

  // Debug logging
  if (typeof window !== 'undefined') {
    console.log('App routing debug:', {
      isAuthenticated,
      onboardingDone,
      subscriptionTier,
      user: user?.id,
      localStorage: {
        onboarding_done: localStorage.getItem('onboarding_done'),
        subscription_tier: localStorage.getItem('subscription_tier')
      }
    });
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка...</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background">
        <Routes>
          {isAuthenticated ? (
            <>
              {/* Если пользователь вошел, ведем по воронке: анкета → тариф → главная */}
              <Route
                path="/"
                element={
                  onboardingDone
                    ? (subscriptionTier ? <Navigate to="/dashboard" replace /> : <Navigate to="/pricing" replace />)
                    : <Navigate to="/questionnaire" replace />
                }
              />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/welcome" element={<Welcome />} />
              <Route path="/questionnaire" element={<Onboarding />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/themes" element={<Themes />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/scanner" element={<Scanner />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/schedule" element={<Schedule />} />
              <Route path="/workout" element={<Workout />} />
              <Route path="/breathing" element={<Breathing />} />
            </>
          ) : (
            <>
              {/* Если пользователь НЕ вошел, показываем эти страницы */}
              <Route path="/" element={<Navigate to="/login" replace />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
            </>
          )}
          <Route path="*" element={<NotFound />} />
        </Routes>
        {/* Показываем нижнюю навигацию, только если пользователь вошел */}
        {isAuthenticated && <BottomNavigation />}
      </div>
    </BrowserRouter>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AppContent />
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;